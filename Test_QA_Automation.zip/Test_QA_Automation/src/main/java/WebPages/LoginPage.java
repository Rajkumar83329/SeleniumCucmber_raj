package WebPages;

import io.cucumber.datatable.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    WebDriver localDriver;

    //constructor name is as class name
    public LoginPage(WebDriver driverInstance) {
        this.localDriver = driverInstance;
        PageFactory.initElements(driverInstance, this);

    }

    WebElement userName;



    public void getUrlMethod() {
        localDriver.get("https://admin-demo.nopcommerce.com/login");
    }

    public WebElement LoginPageTitle() throws InterruptedException {
        WebElement loginTitleElement;
        Thread.sleep(5000);
        loginTitleElement = localDriver.findElement(By.xpath("/html/head/title"));

        Assert.assertEquals(loginTitleElement.getText().toString(), "Your store. Login");
        return null;
    }

    public void UserNameMethod() {

        localDriver.findElement(By.xpath("//input[@type='email']")).clear();

        localDriver.findElement(By.xpath("//input[@type='email']")).sendKeys("admin@yourstore.com");


    }

    public void password() {
        localDriver.findElement(By.xpath("//input[@value='admin']")).clear();
        localDriver.findElement(By.xpath("//input[@value='admin']")).sendKeys("admin");

    }

    public void loginButton() throws InterruptedException {

        localDriver.findElement(By.xpath("//button[@type='submit']")).submit();
        Thread.sleep(8000);
    }

    public WebElement verifyHomepage() {
        //String titleValue= "titleElement.getText()";
        WebElement titleElement;
        titleElement = localDriver.findElement(By.xpath("/html/head/title"));

        Assert.assertEquals(titleElement.getText().toString(), "Dashboard / nopCommerce administration");
        return null;
    }

    public void UserInvalidNameMethod() {

        WebElement invalidUserName = localDriver.findElement(By.xpath("//input[@type='email']"));
        invalidUserName.clear();
        invalidUserName.sendKeys("invalidData_@$###$()");

    }

    public void InvalidPassword() {


        WebElement invalidPasswordElement = localDriver.findElement(By.xpath("//input[@value='admin']"));

        invalidPasswordElement.clear();
        invalidPasswordElement.sendKeys("AKSJFHKFJ");
    }

    public Boolean verifyLoginErrorMethod() {


        WebElement ErrorMessageElement = localDriver.findElement(By.xpath("//div[@class='message-error validation-summary-errors']"));

        if (ErrorMessageElement.getText().contains("unsuccessful")) {
            Assert.assertEquals(ErrorMessageElement.getText(), "Login was unsuccessful. Please correct the errors and try again.");
            System.out.println("invalid scenario is passed");
            return Boolean.TRUE;
        }
        else
            return Boolean.FALSE;
    }
    }
