package WebPageSteps;

import WebPages.LoginPage;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import WebDriverManagerPack.WebDriverClass1;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LoginSteps1 extends WebDriverClass1 {
    // WebDriverClass obj2=new WebDriverClass();
    // obj2.  not able to access methods because WebDriverClass doenst have construct so we can call the methods instead using extends
    //public LoginPage obj;
    //  public WebDriver driver;

    //A constructor in Java is a special method that is used to initialize objects. The constructor is called when an object of a class is created. It can be used to set initial values for object attributes.


 /*   public WebDriver getDriverMethod2() {

        WebDriverManager.chromedriver().setup();
        ChromeOptions chromeOptions = new ChromeOptions();
        WebDriver driver = new ChromeDriver(chromeOptions);
        return driver;
    }     */
   LoginPage obj =new LoginPage(getDriverMethod());

    @Given("user launches the browser")
    public void user_launches_the_browser() {

        System.out.println("launching the browser ");
          obj.getUrlMethod();
       
    }


    @When("user navigates to login page")
    public void user_navigates_to_login_page() throws InterruptedException {
        System.out.println("1");
        //obj = new LoginPage(getDriverMethod());
        obj.LoginPageTitle();

    }

    @When("user enters username and password")
    public void user_enters_username_and_password() {

        obj.UserNameMethod();
        obj.password();
        System.out.println("2");
    }

    @When("user clicks on login page")
    public void user_clicks_on_login_page() throws InterruptedException {

        obj.loginButton();

    }

    @Then("user is navigated to home page")
    public void user_is_navigated_to_home_page() {

        obj.verifyHomepage();
    }

    @When("user enters invalid username and invalid password")
    public void user_enters_invalid_username_and_invalid_password() {
        // Write code here that turns the phrase above into concrete actions
        obj.UserInvalidNameMethod();
        obj.InvalidPassword();
    }


    @Then("verified error message is displayed")
    public void verified_error_message_is_displayed() {
      obj.verifyLoginErrorMethod();
    }
}
