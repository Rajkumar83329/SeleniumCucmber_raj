package WebDriverManagerPack;

import WebPages.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class WebDriverClass1 {


    public WebDriver driver;

    public WebDriver getDriverMethod() {

        WebDriverManager.chromedriver().setup();

        ChromeOptions chromeOptions = new ChromeOptions();
        driver = new ChromeDriver(chromeOptions);

        // LoginPage obj=new LoginPage(driver);
        return driver;
    }
}
