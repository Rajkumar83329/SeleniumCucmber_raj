package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions
        (
        features = "src/test/resources/FeatureFiles_QA_Application_UI/Login.feature",
        glue = {"src/java/WebPageSteps"},
        dryRun = true)
public class Runner {

}


