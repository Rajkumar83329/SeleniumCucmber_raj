package SeleniumPack;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class launchBrowser {

    public static void main(String[]args) throws InterruptedException, IOException {

        System.out.println("test java prog");
       //WebDriverManager.chromedriver().setup();

        final String filepath="src/main/resources/application.properties";
       File fileObj=new File(filepath);
        Properties prop=new Properties();

        FileInputStream inpObj =new FileInputStream(fileObj);
        prop.load(inpObj);


            if (prop.getProperty("browser").equals("chrome")) {
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                WebDriver driver = new ChromeDriver(chromeOptions);
                driver.get("https://www.google.com/");
                driver.manage().window().maximize();
                Thread.sleep(3000);
                driver.findElement(By.xpath("//*[@title='Search']")).sendKeys("key value");

            } else if (prop.getProperty("browser").equals("firefox")) {
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions options = new FirefoxOptions();
                WebDriver driver = new FirefoxDriver(options);


            }
        }

    }



